package org.vovka.birthdaycountdown;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public TextView contacts;
    public FrameLayout.LayoutParams layoutParams;
    final int MY_PERMISSIONS_REQUEST_READ_CONTACTS = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        contacts = findViewById(R.id.tv);
        layoutParams = new FrameLayout.LayoutParams(contacts.getLayoutParams());


        //Получение и отображение контактных данных
        getContacts();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.action_settings:
                //https://alvinalexander.com/android/android-tutorial-preferencescreen-preferenceactivity-preferencefragment
                Intent i = new Intent(this, SettingsActivity.class);
                startActivity(i);
                return true;

            case R.id.action_exit:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_READ_CONTACTS: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    getContacts();
                }
            }
        }
    }

    public void getContacts() {
        try {
            StringBuilder output = new StringBuilder();

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                //https://developer.android.com/training/permissions/requesting.html#java

                showMsgbox(getString(R.string.msg_no_access));
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CONTACTS}, MY_PERMISSIONS_REQUEST_READ_CONTACTS);
                return;

            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                showMsgbox(getString(R.string.msg_no_access));
                return;
            }

            long EventsCount = 0;
            long PersonsCount = 0;
            int BDindex;
            String FIO = "";

            //Получаем требуемые события (дни рождения, и т.п.)
            ContentResolver contentResolver = getContentResolver();
            Cursor cursor = contentResolver.query(
                    android.provider.ContactsContract.Data.CONTENT_URI,
                    null,
                    ContactsContract.Data.MIMETYPE + " = '" + ContactsContract.CommonDataKinds.Event.CONTENT_ITEM_TYPE + "' AND " + ContactsContract.CommonDataKinds.Event.TYPE + " = " + ContactsContract.CommonDataKinds.Event.TYPE_BIRTHDAY,
                    null,
                    ContactsContract.Data.DISPLAY_NAME_ALTERNATIVE
            ); //android.provider.ContactsContract.Data.CONTACT_ID+" = "+contact_id+" AND

            if (cursor != null) {
                if (cursor.getCount() > 0) {
                    while (cursor.moveToNext()) {
                        BDindex = cursor.getColumnIndex("data1");
                        if (cursor.getString(BDindex) != null) {
                            if (!cursor.getString(cursor.getColumnIndex("display_name_alt")).equalsIgnoreCase(FIO)) { //Начало данных контакта
                                output.append("\n\n" + cursor.getString(cursor.getColumnIndex("display_name_alt")).replace(",", ""));
                                FIO = cursor.getString(cursor.getColumnIndex("display_name_alt"));
                                PersonsCount++;

                            /* if (FIO.equalsIgnoreCase("Белов Владимир")) {
                                for (int i = 1; i <= cursor.getColumnCount() - 1; i++) {
                                    if (cursor.getString(i) != null) {
                                        output.append("\n" + cursor.getColumnName(i) + ": " + cursor.getString(i));
                                    }
                                }
                            } */
                            }

                            output.append("\n" + cursor.getString(cursor.getColumnIndex("account_type")) + ": " + cursor.getString(BDindex));
                            EventsCount++;
                        }
                    }


                    if (EventsCount > 0) {
                        //contacts = findViewById(R.id.tv);
                        layoutParams.gravity = Gravity.LEFT | Gravity.TOP;
                        contacts.setLayoutParams(layoutParams);
                        contacts.setText("Персон: " + PersonsCount + ", событий: " + EventsCount + output); //"\nВсего циклов: " + AllCount +
                    } else {
                        showMsgbox(getString(R.string.msg_no_birthdays));
                    }
                } else {
                    showMsgbox(getString(R.string.msg_no_contacts));
                }
                cursor.close();
            }
        }
        catch (Exception e)
            {
                e.printStackTrace();
                Toast.makeText(this, "MainActivity->getContacts:\n" + e.getMessage(), Toast.LENGTH_LONG).show();
            }
    }

    public void showMsgbox(String msg) {
        StringBuffer output = new StringBuffer();
        output.append(msg);

        //https://stackoverflow.com/questions/41199070/android-layout-gravity-for-textview-in-java
        layoutParams.gravity = Gravity.CENTER | Gravity.CENTER_VERTICAL;
        contacts.setLayoutParams(layoutParams);
        contacts.setText(output);
        //contacts.invalidate();
    }
}
